int main()
{
    int a, b, c;
    b = (a + c + b) * (c + a);
    return b;
}

